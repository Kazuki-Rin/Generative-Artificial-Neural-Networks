#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import sys
import neat
import numpy as np
import pickle

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from shared_utils import BASE_DIR, CheckpointManager

DynamicNeatBrain = None
encode_spatial_fourier = None

def _lazy_import_main():
    global DynamicNeatBrain, encode_spatial_fourier
    if DynamicNeatBrain is None:
        from main_life_loop import DynamicNeatBrain as DNB, encode_spatial_fourier as esf
        DynamicNeatBrain = DNB
        encode_spatial_fourier = esf

from sandbox_env import VPetEnvironment

# =========================================================================
# CO-TRAINING PIPELINE SIMULATION
# =========================================================================

def load_frozen_brain(model_id: str, config_rel_path: str):
    """Load một model NEAT đã train (frozen) để inference."""
    _lazy_import_main()
    config_path = os.path.join(BASE_DIR, config_rel_path)
    brain = DynamicNeatBrain(model_id, config_path=config_path)
    # Đảm bảo load checkpoint canonical
    try:
        chkpt = CheckpointManager.load(model_id, is_torch=False)
        if chkpt and isinstance(chkpt, dict) and "model_state" in chkpt:
            brain.live_state = chkpt["model_state"]
        elif chkpt:
            brain.live_state = chkpt
        if brain.live_state:
            config = neat.Config(neat.DefaultGenome, neat.DefaultReproduction,
                                 neat.DefaultSpeciesSet, neat.DefaultStagnation, config_path)
            brain.active_net = neat.nn.RecurrentNetwork.create(brain.live_state, config)
    except Exception as e:
        print(f"⚠️ [{model_id}] Load checkpoint failed: {e}. Using random init.")
    return brain

def simulate_m9_fusion(m1a_out, m1b_out, m3_out) -> list:
    """
    Mô phỏng M9 Thalamus: Fusion các output từ M1a, M1b, M3 thành vector cho M4.
    M4 config-m4 yêu cầu 10 inputs.
    """
    # M1a: 2D (target x,y) -> Fourier 10D
    m1a_fourier = encode_spatial_fourier(m1a_out[0], m1a_out[1], dim=10) if len(m1a_out) >= 2 else [0.0]*10
    # M1b: 2D (obj_class, conf) -> 2D
    m1b_vec = m1b_out[:2] if len(m1b_out) >= 2 else [0.0, 0.0]
    # M3: 2D (pred_next_x, pred_next_y) -> Fourier 10D
    m3_fourier = encode_spatial_fourier(m3_out[0], m3_out[1], dim=10) if len(m3_out) >= 2 else [0.0]*10
    
    # Fusion: Concatenate rồi project về 10D (giả lập attention routing)
    fused = m1a_fourier + m1b_vec + m3_fourier # 22D
    # Đơn giản: lấy 10D đầu hoặc average pooling
    if len(fused) > 10:
        # Average pooling 22 -> 10
        step = len(fused) / 10
        pooled = [np.mean(fused[int(i*step):int((i+1)*step)]) for i in range(10)]
        return pooled
    return fused[:10] + [0.0]*(10-len(fused))

def eval_m4_co_training(genomes, config):
    """
    Hàm fitness cho M4: M4 phải học điều khiển dựa trên input từ M1a/M1b/M3 (qua M9 fusion).
    """
    # 1. Khởi tạo môi trường
    env = VPetEnvironment(screen_width=800, screen_height=600)
    
    # 2. Load các model cảm giác (FROZEN - chỉ inference)
    print("   [CoTrain] Loading sensory models (M1a, M1b, M3)...")
    m1a = load_frozen_brain("M1a_Dorsal", "01_Sensory_Inputs/M1_Eye_Vision/config-m1a-cppn")
    m1b = load_frozen_brain("M1b_Ventral", "01_Sensory_Inputs/M1_Eye_Vision/config-m1b-cppn")
    m3  = load_frozen_brain("M3_Spatial", "01_Sensory_Inputs/M3_Spatial_Parietal/config-m3")
    
    if not m1a.active_net or not m1b.active_net or not m3.active_net:
        print("   ❌ [CoTrain] Sensory models not ready. Aborting generation.")
        for gid, g in genomes: g.fitness = -100.0
        return

    # 3. Targets ngẫu nhiên
    targets = [(100, 100), (700, 500), (400, 100), (100, 500), (700, 100)]
    
    for genome_id, genome in genomes:
        genome.fitness = 0.0
        net_m4 = neat.nn.RecurrentNetwork.create(genome, config)
        
        # Reset Asuna
        env.asuna_x, env.asuna_y = 400.0, 300.0
        
        for tx, ty in targets:
            env.spawn_target(tx, ty)
            
            # Mỗi target cho 15 steps để đuổi kịp
            for step in range(15):
                # --- PIPELINE: ENV -> M1/M3 -> M9 -> M4 ---
                
                # 1. ENV -> M1a/M1b (Vision) & M3 (Spatial)
                # M1a/M1b input: Retina 20D (giả lập từ env)
                # Ở đây dùng spatial observation làm proxy cho vision input
                spatial_obs = env.get_spatial_observation() # [rel_x, rel_y]
                proprio = env.get_proprioception()          # [ax, ay]
                
                # Tạo input 20D cho M1a/M1b (giả lập retina)
                # Pad spatial_obs (2D) + proprio (2D) + noise -> 20D
                retina_input = np.concatenate([spatial_obs, proprio, np.zeros(16)])
                
                # Inference M1a (Where)
                m1a_out = m1a.active_net.activate(retina_input) if m1a.active_net else [0.5, 0.5]
                # Inference M1b (What) 
                m1b_out = m1b.active_net.activate(retina_input) if m1b.active_net else [0.0, 0.0]
                # Inference M3 (Spatial Prediction) - Input 10D history
                m3_history = [env.asuna_x/800, env.asuna_y/600] * 5 # Dummy history
                m3_out = m3.active_net.activate(m3_history) if m3.active_net else [0.5, 0.5]
                
                # 2. M9 Fusion -> M4 Input (10D)
                m4_input = simulate_m9_fusion(m1a_out, m1b_out, m3_out)
                
                # 3. M4 Decision
                try:
                    action = net_m4.activate(m4_input[:config.genome_config.num_inputs])
                    if len(action) >= 2:
                        dx, dy = action[0], action[1]
                        env.update_position(dx, dy, speed_multiplier=20.0)
                    else:
                        genome.fitness -= 1.0; break
                except Exception as e:
                    genome.fitness -= 5.0; break
            
            # Tính Fitness: Khoảng cách cuối cùng tới target
            dist = ((env.target_x - env.asuna_x)**2 + (env.target_y - env.asuna_y)**2)**0.5
            # Reward: Max 100 per target, decay with distance
            reward = max(0.0, 100.0 - dist * 0.5)
            genome.fitness += reward

def run_co_training():
    print("="*60)
    print("⚔️ TRƯỜNG HUẤN LUYỆN LIÊN HỢP THỰC SỰ (TRUE CO-TRAINING)")
    print("   Pipeline: ENV -> M1a/M1b/M3 -> M9 Fusion -> M4 -> ENV")
    print("="*60)
    
    config_path = os.path.join(BASE_DIR, "02_Motor_Actuators", "M4_Motor_Cortex", "config-m4")
    if not os.path.exists(config_path):
        print(f"❌ Không tìm thấy config M4: {config_path}")
        return

    config = neat.Config(neat.DefaultGenome, neat.DefaultReproduction,
                         neat.DefaultSpeciesSet, neat.DefaultStagnation, config_path)

    p = neat.Population(config)
    p.add_reporter(neat.StdOutReporter(True))
    stats = neat.StatisticsReporter()
    p.add_reporter(stats)

    print("🏃‍♂️ [M4_Motor] Bắt đầu Co-training 10 generations...")
    winner = p.run(eval_m4_co_training, 10)

    print("\n🏆 [Kết quả] Co-training hoàn tất!")
    print(f"   Best Fitness: {winner.fitness:.2f}")
    
    extra_st = {
        "generation": p.generation,
        "fitness": winner.fitness if winner.fitness else 0.0,
        "topology_version": 1,
        "co_trained_with": ["M1a_Dorsal", "M1b_Ventral", "M3_Spatial"],
        "training_mode": "True_CoTraining_M9_Fusion"
    }
    
    import pickle
    import binascii
    try:
        success = CheckpointManager.save("M4_Motor", winner, is_torch=False, extra_states=extra_st)
        
        if success:
            print("✅ [M4_Motor] Đã lưu Canonical Checkpoint từ True Co-training!")
        else:
            print("❌ Lỗi khi lưu Checkpoint (Backend CheckpointManager từ chối).")
    except Exception as e:
        print(f"❌ Lỗi Pickle/Serialization khi lưu Checkpoint: {e}")

if __name__ == "__main__":
    run_co_training()