import os

# Tên file đầu ra
BUNDLE_FILE_NAME = "full_project_bundle.txt"

# Các thư mục cốt lõi được phép quét (đã bổ sung thư mục "Test")
ALLOWED_ROOT_DIRS = {
    "00_Central_Router",
    "01_Sensory_Inputs",
    "02_Motor_Actuators",
    "03_Cognitive_Core",
    "04_Memory_System",
    "05_Vocal_System",
    "06_Laboratory",
    "Environments",
    "Test"  # Thêm thư mục Test
}

# Các file đơn lẻ nằm ngay ở thư mục gốc cần được đóng gói
ALLOWED_ROOT_FILES = {
    "apply_p2_hashes.py",
    "architecture_manifest.json",
    "asuna_launcher.py",
    "brain_manifest.json",
    "core_bus.py",
    "episode_manager.py",
    "main_life_loop.py",
    "migrate_chroma_ids.py",
    "migration_and_repair.py",
    "replay_buffer.py",
    "requirements.txt",
    "reward_engine.py",
    "shared_utils.py"
}

ALLOWED_EXTS = {'.py', '.json', '.yaml', '.yml', '.ini', '.cfg'}
IGNORE_DIRS = {'__pycache__', '.pytest_cache'}

def should_include(rel_path, filename):
    parts = rel_path.replace("\\", "/").split("/")
    
    # Nếu file nằm ngay ở thư mục gốc
    if len(parts) == 1:
        return filename in ALLOWED_ROOT_FILES and filename != BUNDLE_FILE_NAME
    
    # Nếu file nằm trong các thư mục con cấp phép
    top_dir = parts[0]
    if top_dir not in ALLOWED_ROOT_DIRS:
        return False
        
    # Kiểm tra phần mở rộng hoặc tiền tố cấu hình
    ext = os.path.splitext(filename)[1].lower()
    if ext in ALLOWED_EXTS or filename.startswith("config-"):
        return True
        
    return False

with open(BUNDLE_FILE_NAME, "w", encoding="utf-8") as out:
    for root, dirs, files in os.walk("."):
        # Lọc bỏ thư mục không được phép ở thư mục gốc
        if root == ".":
            dirs[:] = [d for d in dirs if d in ALLOWED_ROOT_DIRS]
        
        # Bỏ qua các thư mục cache rác ở mọi cấp thư mục
        dirs[:] = [d for d in dirs if d not in IGNORE_DIRS]
            
        for f in sorted(files):
            if f == BUNDLE_FILE_NAME:
                continue
                
            rel_path = os.path.relpath(os.path.join(root, f), ".")
            
            if should_include(rel_path, f):
                normalized_path = rel_path.replace("\\", "/")
                out.write(f"\n{'='*80}\nFILE: {normalized_path}\n{'='*80}\n")
                try:
                    with open(os.path.join(root, f), "r", encoding="utf-8") as src:
                        out.write(src.read() + "\n")
                except Exception as e:
                    out.write(f"[ERROR READING FILE: {e}]\n")

print(f"✅ Đã đóng gói chính xác các file mã nguồn (bao gồm cả thư mục Test) vào {BUNDLE_FILE_NAME}!")